"""
core/intent_cache.py

Layer 2 of the deterministic NLQ pipeline: a PERMANENT, disk-based cache
that survives page refreshes and new sessions (unlike st.session_state,
which is Layer 1 and lost on refresh).

Each entry is keyed by the question fingerprint (see question_normaliser.py)
and stores:
    - the original question (for display / debugging)
    - the structured intent JSON (the reusable, LLM-free artifact)
    - the compiled SQL that was produced from it
    - whether the entry is a validated "intent" or a canonicalised
      "raw_sql" fallback (see sql_compiler.compile / nlq_engine)

Using this cache means the LLM is called AT MOST ONCE per unique
(normalised) question, ever — solving the "4 days later, different SQL"
problem described in prompt.md.
"""
import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager

_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".cache")
_DB_PATH = os.path.join(_DB_DIR, "intent_cache.sqlite")

_lock = threading.Lock()
_initialized = False


def _ensure_db() -> None:
    global _initialized
    if _initialized:
        return
    with _lock:
        if _initialized:
            return
        os.makedirs(_DB_DIR, exist_ok=True)
        with _connect() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS intent_cache (
                    fingerprint   TEXT PRIMARY KEY,
                    question      TEXT NOT NULL,
                    entry_type    TEXT NOT NULL,   -- 'intent' | 'raw_sql'
                    intent_json   TEXT,             -- NULL for raw_sql entries
                    sql           TEXT NOT NULL,
                    hit_count     INTEGER NOT NULL DEFAULT 0,
                    created_at    REAL NOT NULL,
                    updated_at    REAL NOT NULL
                )
                """
            )
            con.commit()
        _initialized = True


@contextmanager
def _connect():
    con = sqlite3.connect(_DB_PATH, timeout=10)
    try:
        yield con
    finally:
        con.close()


def get(fingerprint: str) -> dict | None:
    """Return the cached entry for a fingerprint, or None on a miss."""
    _ensure_db()
    with _lock, _connect() as con:
        row = con.execute(
            "SELECT question, entry_type, intent_json, sql, hit_count "
            "FROM intent_cache WHERE fingerprint = ?",
            (fingerprint,),
        ).fetchone()
        if row is None:
            return None
        question, entry_type, intent_json, sql, hit_count = row
        con.execute(
            "UPDATE intent_cache SET hit_count = hit_count + 1, updated_at = ? "
            "WHERE fingerprint = ?",
            (time.time(), fingerprint),
        )
        con.commit()
        return {
            "question": question,
            "entry_type": entry_type,
            "intent": json.loads(intent_json) if intent_json else None,
            "sql": sql,
            "hit_count": hit_count,
        }


def put(fingerprint: str, question: str, sql: str, intent: dict | None = None) -> None:
    """
    Persist an intent (+ compiled SQL) or a canonicalised raw_sql fallback.
    entry_type is inferred from whether `intent` is provided.
    """
    _ensure_db()
    entry_type = "intent" if intent is not None else "raw_sql"
    intent_json = json.dumps(intent) if intent is not None else None
    now = time.time()
    with _lock, _connect() as con:
        con.execute(
            """
            INSERT INTO intent_cache
                (fingerprint, question, entry_type, intent_json, sql, hit_count, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 0, ?, ?)
            ON CONFLICT(fingerprint) DO UPDATE SET
                question=excluded.question,
                entry_type=excluded.entry_type,
                intent_json=excluded.intent_json,
                sql=excluded.sql,
                updated_at=excluded.updated_at
            """,
            (fingerprint, question, entry_type, intent_json, sql, now, now),
        )
        con.commit()


def all_questions(limit: int = 50) -> list[str]:
    """Return recently cached questions — used to power 'similar questions I can answer' suggestions."""
    _ensure_db()
    with _lock, _connect() as con:
        rows = con.execute(
            "SELECT question FROM intent_cache ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [r[0] for r in rows]


def clear() -> None:
    """Wipe the persistent cache (used for tests / manual reset)."""
    _ensure_db()
    with _lock, _connect() as con:
        con.execute("DELETE FROM intent_cache")
        con.commit()
