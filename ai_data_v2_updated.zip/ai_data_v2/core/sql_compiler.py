"""
core/sql_compiler.py

Layer 2 of the deterministic NLQ pipeline (see prompt.md):

    SAME intent JSON -> ALWAYS identical SQL output.
    No LLM involved — pure Python string building.

Rules applied consistently every single time:
  - Column aliases always follow the same naming convention
  - Aggregation functions always chosen the same way (from the intent)
  - Date filters always use the same strftime patterns
  - ORDER BY + LIMIT always applied in the same position
  - GROUP BY always sorted alphabetically (stable column order)
  - Window-function intents (RANKING_WITHIN_GROUP / RUNNING_TOTAL /
    YOY_GROWTH) use fixed, named SQL TEMPLATES — never freeform LLM SQL —
    so the same intent always compiles to the same CTE structure.

This module never calls the LLM. It only ever raises ValueError for an
intent it does not (yet) know how to compile — the caller (nlq_engine)
treats that as "no template match" and falls back to Approach-3 (guarded
LLM SQL generation), per the design in prompt.md.
"""
from __future__ import annotations

DEFAULT_LIMIT_RANKING = 10
MAX_ROWS = 500

_GRAIN_EXPR = {
    "day":     ("strftime('%Y-%m-%d', {col})", "day"),
    "month":   ("strftime('%Y-%m', {col})", "month"),
    "quarter": ("strftime('%Y', {col}) || '-Q' || CAST(((CAST(strftime('%m', {col}) AS INTEGER)-1)/3)+1 AS VARCHAR)", "quarter"),
    "year":    ("strftime('%Y', {col})", "year"),
}

_FILTER_OPS = {
    "equals":        lambda col, val: f"{col} = {_lit(val)}",
    "not_equals":    lambda col, val: f"{col} != {_lit(val)}",
    "contains":      lambda col, val: f"{col} ILIKE '%{_escape(val)}%'",
    "greater_than":  lambda col, val: f"{col} > {_lit(val)}",
    "less_than":     lambda col, val: f"{col} < {_lit(val)}",
    "greater_equal": lambda col, val: f"{col} >= {_lit(val)}",
    "less_equal":    lambda col, val: f"{col} <= {_lit(val)}",
    "in":            lambda col, val: f"{col} IN ({', '.join(_lit(v) for v in val)})",
    "year_equals":   lambda col, val: f"strftime('%Y', {col}) = '{_escape(str(val))}'",
    "between":       lambda col, val: f"{col} BETWEEN {_lit(val[0])} AND {_lit(val[1])}",
}


class CompilerError(ValueError):
    """Raised when an intent cannot be compiled deterministically."""


def _escape(v: str) -> str:
    return str(v).replace("'", "''")


def _lit(v) -> str:
    if isinstance(v, (int, float)):
        return str(v)
    return f"'{_escape(v)}'"


def _alias(name: str) -> str:
    """Canonical alias naming convention: lowercase snake_case."""
    return "_".join(str(name).strip().lower().replace("-", " ").split())


def _measure_select(measures: list[dict]) -> list[str]:
    parts = []
    for m in measures:
        expr = m["expression"]
        alias = _alias(m.get("alias") or m["name"])
        parts.append(f"{expr} AS {alias}")
    return parts


def _dimension_select(dimensions: list[dict]) -> list[str]:
    parts = []
    for d in dimensions:
        expr = d.get("display") or d["column"]
        alias = _alias(d.get("alias") or d["column"])
        parts.append(f"{expr} AS {alias}")
    return parts


def _dimension_aliases(dimensions: list[dict]) -> list[str]:
    return [_alias(d.get("alias") or d["column"]) for d in dimensions]


def _where_clause(filters: list[dict]) -> str:
    if not filters:
        return ""
    clauses = []
    for f in filters:
        op = f.get("operator", "equals")
        fn = _FILTER_OPS.get(op)
        if fn is None:
            raise CompilerError(f"Unsupported filter operator: {op}")
        clauses.append(fn(f["column"], f["value"]))
    return "WHERE " + " AND ".join(clauses)


def _order_by_clause(order_by: list[dict], fallback_alias: str | None) -> str:
    if order_by:
        parts = [f"{_alias(o['column'])} {o.get('direction', 'DESC').upper()}" for o in order_by]
        return "ORDER BY " + ", ".join(parts)
    if fallback_alias:
        return f"ORDER BY {fallback_alias} DESC"
    return ""


def _limit_clause(limit: int | None, default: int | None = None) -> str:
    n = limit if limit is not None else default
    if n is None:
        return ""
    n = min(int(n), MAX_ROWS)
    return f"LIMIT {n}"


# ---------------------------------------------------------------------
# FLAT INTENT TYPES: SIMPLE / RANKING / FILTERED / TIME_SERIES /
#                     COMPARISON / MULTI_DIM / DERIVED_KPI
# ---------------------------------------------------------------------
def _compile_flat(intent: dict) -> str:
    measures = intent.get("measures") or []
    dimensions = list(intent.get("dimensions") or [])
    filters = intent.get("filters") or []
    order_by = intent.get("order_by") or []
    limit = intent.get("limit")
    intent_type = intent["intent_type"]

    if not measures:
        raise CompilerError("intent has no measures")

    # TIME_SERIES injects a deterministic time dimension.
    if intent_type == "time_series":
        date_col = intent.get("date_column")
        grain = (intent.get("time_grain") or "month").lower()
        if not date_col or grain not in _GRAIN_EXPR:
            raise CompilerError("time_series intent missing date_column/time_grain")
        expr_tpl, alias = _GRAIN_EXPR[grain]
        dimensions = [{"column": date_col, "display": expr_tpl.format(col=date_col), "alias": alias}] + dimensions

    select_parts = _dimension_select(dimensions) + _measure_select(measures)
    dim_aliases = _dimension_aliases(dimensions)

    # GROUP BY: sorted alphabetically for a stable, deterministic column order.
    group_by_clause = ""
    if dim_aliases:
        group_by_clause = "GROUP BY " + ", ".join(sorted(dim_aliases))

    where_clause = _where_clause(filters)

    default_limit = DEFAULT_LIMIT_RANKING if intent_type == "ranking" else None
    fallback_order_alias = _alias(measures[0].get("alias") or measures[0]["name"]) if intent_type == "ranking" else None
    order_clause = _order_by_clause(order_by, fallback_order_alias)
    limit_clause = _limit_clause(limit, default=default_limit)

    lines = [
        f"SELECT {', '.join(select_parts)}",
        "FROM df",
    ]
    if where_clause:
        lines.append(where_clause)
    if group_by_clause:
        lines.append(group_by_clause)
    if order_clause:
        lines.append(order_clause)
    if limit_clause:
        lines.append(limit_clause)
    return "\n".join(lines)


# ---------------------------------------------------------------------
# TEMPLATE: RANK_WITHIN_GROUP
#   RANK() OVER (PARTITION BY ... ORDER BY measure DESC)
#   Rule: always DENSE_RANK unless the user explicitly asked "with gaps".
# ---------------------------------------------------------------------
def _compile_rank_within_group(intent: dict) -> str:
    measures = intent.get("measures") or []
    dimensions = intent.get("dimensions") or []
    partition = intent.get("partition_by") or []
    n = intent.get("n") or DEFAULT_LIMIT_RANKING
    use_gaps = bool(intent.get("with_gaps"))
    if not measures or not dimensions or not partition:
        raise CompilerError("rank_within_group requires measures, dimensions and partition_by")

    measure_alias = _alias(measures[0].get("alias") or measures[0]["name"])
    partition_aliases = [_alias(p) for p in partition]
    select_parts = _dimension_select(dimensions) + _measure_select(measures)
    dim_aliases = sorted(_dimension_aliases(dimensions))
    rank_fn = "RANK" if use_gaps else "DENSE_RANK"

    inner = "\n".join([
        f"SELECT {', '.join(select_parts)}",
        "FROM df",
        f"GROUP BY {', '.join(dim_aliases)}" if dim_aliases else "",
    ]).strip()

    outer_alias = f"rank_within_{'_'.join(partition_aliases)}"
    # A window function's own alias cannot be referenced in the WHERE of the
    # same SELECT (DuckDB, like most engines, evaluates WHERE before window
    # functions) — so the ranked SELECT is wrapped in one more deterministic
    # layer that filters on the already-materialised rank column.
    sql = f"""SELECT * FROM (
  SELECT *,
         {rank_fn}() OVER (
           PARTITION BY {', '.join(partition_aliases)}
           ORDER BY {measure_alias} DESC
         ) AS {outer_alias}
  FROM (
{inner}
  ) ranked
) scored
WHERE {outer_alias} <= {int(n)}
ORDER BY {', '.join(partition_aliases)}, {outer_alias}"""
    return sql


# ---------------------------------------------------------------------
# TEMPLATE: RUNNING_TOTAL
#   Rule: always ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
#         (never RANGE BETWEEN — avoids tie-handling ambiguity)
# ---------------------------------------------------------------------
def _compile_running_total(intent: dict) -> str:
    measures = intent.get("measures") or []
    partition = intent.get("partition_by") or []
    date_col = intent.get("date_column")
    if not measures or not date_col:
        raise CompilerError("running_total requires measures and date_column")

    measure = measures[0]
    measure_expr = measure["expression"]
    measure_alias = _alias(measure.get("alias") or measure["name"])
    partition_aliases = [_alias(p) for p in partition]
    dims = intent.get("dimensions") or [{"column": p} for p in partition]
    dim_aliases = _dimension_aliases(dims)
    select_dims = _dimension_select(dims)

    partition_sql = f"PARTITION BY {', '.join(partition_aliases)}\n         " if partition_aliases else ""
    group_cols = sorted(set(dim_aliases + [_alias(date_col)]))

    sql = f"""SELECT {', '.join(select_dims)},
       {date_col} AS {_alias(date_col)},
       {measure_expr} AS {measure_alias},
       SUM({measure_expr}) OVER (
         {partition_sql}ORDER BY {date_col}
         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS running_total
FROM df
GROUP BY {', '.join(group_cols)}
ORDER BY {', '.join(group_cols)}"""
    return sql


# ---------------------------------------------------------------------
# TEMPLATE: YOY_GROWTH
#   Deterministic two-CTE join, always named current_year / prior_year.
# ---------------------------------------------------------------------
def _compile_yoy_growth(intent: dict) -> str:
    measures = intent.get("measures") or []
    dimensions = intent.get("dimensions") or []
    date_col = intent.get("date_column")
    current_year = intent.get("current_year")
    if not measures or not dimensions or not date_col or current_year is None:
        raise CompilerError("yoy_growth requires measures, dimensions, date_column, current_year")

    measure = measures[0]
    measure_expr = measure["expression"]
    dim_aliases = sorted(_dimension_aliases(dimensions))
    select_dims = _dimension_select(dimensions)
    prior_year = int(current_year) - 1

    join_on = " AND ".join(f"c.{a} = p.{a}" for a in dim_aliases)
    select_dims_c = ", ".join(f"c.{a}" for a in dim_aliases)

    sql = f"""WITH current_year AS (
  SELECT {', '.join(select_dims)}, {measure_expr} AS current_rev
  FROM df
  WHERE strftime('%Y', {date_col}) = '{current_year}'
  GROUP BY {', '.join(dim_aliases)}
),
prior_year AS (
  SELECT {', '.join(select_dims)}, {measure_expr} AS prior_rev
  FROM df
  WHERE strftime('%Y', {date_col}) = '{prior_year}'
  GROUP BY {', '.join(dim_aliases)}
)
SELECT {select_dims_c},
       c.current_rev,
       p.prior_rev,
       ROUND((c.current_rev - p.prior_rev) / NULLIF(p.prior_rev, 0) * 100, 2) AS yoy_growth_pct
FROM current_year c
LEFT JOIN prior_year p ON {join_on}
ORDER BY yoy_growth_pct DESC"""
    return sql


_TEMPLATE_COMPILERS = {
    "simple": _compile_flat,
    "ranking": _compile_flat,
    "filtered": _compile_flat,
    "time_series": _compile_flat,
    "comparison": _compile_flat,
    "multi_dim": _compile_flat,
    "derived_kpi": _compile_flat,
    "rank_within_group": _compile_rank_within_group,
    "running_total": _compile_running_total,
    "yoy_growth": _compile_yoy_growth,
}


def supported_intent_types() -> list[str]:
    return sorted(_TEMPLATE_COMPILERS.keys())


def compile_intent(intent: dict) -> str:
    """
    Compile a validated intent JSON into deterministic DuckDB SQL.
    Same intent in -> byte-identical SQL out, every time.
    """
    intent_type = (intent or {}).get("intent_type", "").lower()
    compiler = _TEMPLATE_COMPILERS.get(intent_type)
    if compiler is None:
        raise CompilerError(f"No deterministic template for intent_type={intent_type!r}")
    return compiler(intent)
