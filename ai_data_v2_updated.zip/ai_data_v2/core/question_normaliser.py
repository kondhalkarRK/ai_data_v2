"""
core/question_normaliser.py

Turns a raw natural-language question into a stable, canonical form so that
semantically-identical questions ("Top 10 salespeople by Revenue",
"top 10 sales people by revenue", "show me top 10 salespeople revenue")
all resolve to the SAME cache key.

This is Layer 0 of the deterministic NLQ pipeline described in prompt.md:
    Question Normaliser -> stable fingerprint -> Intent Cache lookup
"""
import hashlib
import re

# Words that don't change the meaning of an analytical question — stripped
# before hashing so they don't create spurious cache misses.
_STOP_WORDS = {
    "show", "me", "give", "list", "display", "please", "the", "a", "an",
    "of", "for", "in", "on", "to", "with", "by", "and", "get", "find",
    "what", "is", "are", "tell", "can", "you", "i", "want", "need",
    "my", "our", "this", "that", "as", "it", "its",
}

# Prefix injected by ui/tab_query.py when the semantic layer resolves
# measures/dimensions before calling run_query(). It must be stripped so
# caching/normalisation is based on the user's actual words, not on
# session-dependent semantic hints.
_SEMANTIC_HINT_RE = re.compile(r"^\[Semantic hints[^\]]*\]\s*", re.IGNORECASE)

_PUNCT_RE = re.compile(r"[^\w\s]")
_WS_RE = re.compile(r"\s+")


def strip_semantic_hints(question: str) -> str:
    """Remove any leading '[Semantic hints — ...]' prefix injected by the UI."""
    return _SEMANTIC_HINT_RE.sub("", question or "").strip()


def normalize_question(question: str) -> str:
    """
    Produce a canonical string representation of a question:
      1. Strip UI-injected semantic hint prefixes
      2. Lowercase
      3. Remove punctuation
      4. Remove stop words
      5. Sort remaining meaningful tokens alphabetically

    "Top 10 salespeople by Revenue"      -> "10 revenue salespeople top"
    "show me top 10 salespeople revenue" -> "10 revenue salespeople top"
    """
    q = strip_semantic_hints(question or "")
    q = q.lower()
    q = _PUNCT_RE.sub(" ", q)
    tokens = [t for t in _WS_RE.split(q.strip()) if t]
    tokens = [t for t in tokens if t not in _STOP_WORDS]
    tokens.sort()
    return " ".join(tokens)


def question_fingerprint(question: str) -> str:
    """Stable hash used as the permanent intent-cache key for a question."""
    canonical = normalize_question(question)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]
