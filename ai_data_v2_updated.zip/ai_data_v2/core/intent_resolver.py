"""
core/intent_resolver.py

Layer 1 of the deterministic NLQ pipeline (see prompt.md):

    Converts natural language -> a structured Intent Object (JSON).
    NOT SQL — a stable intermediate representation.

This is the ONLY place in the deterministic path that calls the LLM, and
it is only called on a full cache miss (see core/intent_cache.py). Once an
intent is resolved and validated it is cached forever, so the LLM never
needs to be called again for the same (normalised) question.

core/sql_compiler.py then turns the validated intent into SQL — with no
further LLM involvement.
"""
from __future__ import annotations

import json
import re

import pandas as pd

from core.llm_client import call_llm
from core.schema_builder import build_rich_schema
from core.sql_compiler import supported_intent_types

_JSON_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)

_INTENT_SCHEMA_HINT = """
Return ONLY a single JSON object (no markdown fences, no prose) describing
the user's question as a structured intent. Use this exact shape:

{
  "intent_type": one of ["simple","ranking","filtered","time_series","comparison",
                          "multi_dim","derived_kpi","rank_within_group",
                          "running_total","yoy_growth"],
  "measures": [{"name": "<short_name>", "expression": "<valid DuckDB SQL aggregate expression using only listed columns>", "alias": "<snake_case alias>"}],
  "dimensions": [{"column": "<exact column name from COLUMNS list>", "display": "<optional SQL expression, e.g. to concat first+last name>", "alias": "<snake_case alias>"}],
  "filters": [{"column": "<exact column name>", "operator": "equals|not_equals|contains|greater_than|less_than|greater_equal|less_equal|in|year_equals|between", "value": <string|number|list|[low,high]>}],
  "order_by": [{"column": "<alias used above>", "direction": "ASC|DESC"}],
  "limit": <integer or null>,
  "date_column": "<exact date column name, required for time_series/running_total/yoy_growth>",
  "time_grain": "day|month|quarter|year (time_series only)",
  "partition_by": ["<alias>", ...]  (rank_within_group/running_total only),
  "n": <integer>  (rank_within_group only, defaults to 10),
  "current_year": <integer>  (yoy_growth only),
  "with_gaps": <true|false>  (rank_within_group only; false unless user explicitly asked "with gaps")
}

Rules:
- Only use column names that literally appear in the COLUMNS list below.
- measures/dimensions/filters are always arrays, even if there is exactly one.
- Omit fields that don't apply to the chosen intent_type rather than inventing values.
- Prefer "ranking" whenever the user asks for top/bottom N.
- Prefer "time_series" whenever the user asks for a trend/by month/by quarter/by year.
- Use "rank_within_group" for "top N per <group>" questions.
- Use "running_total"/"yoy_growth" only when explicitly implied by the question.
- If nothing in the schema can answer the question, return {"intent_type": "unsupported", "reason": "<short reason>"}.
"""


def _strip_fences(text: str) -> str:
    return _JSON_FENCE_RE.sub("", text or "").strip()


def build_intent_prompt(question: str, df: pd.DataFrame) -> str:
    schema = build_rich_schema(df)
    return f"""You are an expert semantic-layer intent extractor for an analytics tool.
Given a dataset schema and a natural language question, extract a structured
INTENT describing WHAT the user wants — never write SQL yourself.

TABLE NAME: df
{schema}

{_INTENT_SCHEMA_HINT}

QUESTION: {question}

JSON:"""


def resolve_intent(question: str, df: pd.DataFrame, status=None) -> dict | None:
    """Call the LLM once to resolve `question` into a structured intent JSON."""
    if status is not None:
        status.update(label="🧭 Resolving question into a structured intent...")
    prompt = build_intent_prompt(question, df)
    raw = call_llm(prompt)
    if not raw:
        return None
    raw = _strip_fences(raw)
    try:
        intent = json.loads(raw)
    except json.JSONDecodeError:
        # Be forgiving of a stray prefix/suffix around the JSON object.
        start, end = raw.find("{"), raw.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        try:
            intent = json.loads(raw[start:end + 1])
        except json.JSONDecodeError:
            return None
    return intent if isinstance(intent, dict) else None


def validate_intent(intent: dict, df: pd.DataFrame) -> tuple[bool, str]:
    """
    Structural + column-existence validation, run BEFORE the intent is
    compiled or cached. Cheap, deterministic, zero LLM tokens.
    """
    if not isinstance(intent, dict):
        return False, "Intent is not a JSON object."

    intent_type = intent.get("intent_type")
    if intent_type == "unsupported":
        return False, intent.get("reason", "The question could not be mapped to the available data.")
    if intent_type not in supported_intent_types():
        return False, f"Unknown intent_type: {intent_type!r}"

    columns = set(df.columns)

    measures = intent.get("measures") or []
    if not isinstance(measures, list) or not measures:
        return False, "Intent has no measures."
    for m in measures:
        if "expression" not in m or "name" not in m:
            return False, "Measure entry missing 'name' or 'expression'."
        # Loose check: every bare column token referenced in the expression
        # should exist in the dataframe, to catch hallucinated columns.
        tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", m["expression"])
        sql_keywords = {
            "sum", "count", "avg", "min", "max", "distinct", "as", "nullif",
            "round", "cast", "integer", "decimal", "varchar", "case", "when",
            "then", "else", "end", "over", "partition", "by", "order",
        }
        referenced = [t for t in tokens if t.lower() not in sql_keywords]
        unknown = [t for t in referenced if t not in columns and not t.isdigit()]
        if unknown and not any(u in columns for u in referenced):
            return False, f"Measure expression references unknown column(s): {unknown}"

    for d in intent.get("dimensions") or []:
        if "column" not in d:
            return False, "Dimension entry missing 'column'."
        if d["column"] not in columns:
            return False, f"Dimension column not found in dataset: {d['column']!r}"

    for f in intent.get("filters") or []:
        if "column" not in f or "operator" not in f or "value" not in f:
            return False, "Filter entry missing 'column', 'operator' or 'value'."
        if f["column"] not in columns:
            return False, f"Filter column not found in dataset: {f['column']!r}"

    date_col = intent.get("date_column")
    if date_col and date_col not in columns:
        return False, f"date_column not found in dataset: {date_col!r}"

    limit = intent.get("limit")
    if limit is not None and not isinstance(limit, int):
        return False, "limit must be an integer or null."

    return True, ""
